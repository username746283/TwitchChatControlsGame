# DougDoug Note:
# This file contains your Twitch account info for logging into the chat
# Your oauth-token can be generated at http://twitchapps.com/tmi/

# WARNING: DO NOT PUBLICLY SHARE THIS INFORMATION. THIS INFO IS USED TO ACCESS YOUR TWITCH ACCOUNT.

# TODO: put your Twitch username and OAuth token here
TWITCH_USERNAME = 'username746283'
TWITCH_OAUTH_TOKEN = 'oauth:wskaleavkpp6x34q7d4omp8ojwzn64'
